A simple SMS spam detector using LLMs.

1) Create a new python virtual enviroment.
2) Incase you have nvidia graphics card just install the requirements.txt
3) Huggingface is required. The installation of Huggingface is system specific (different process for amd/nvdia gpus).
4) Wandb is required. You have to create an account and link your personal access token so you have access to it's api.
5) Run main.py

The specs of the system the project was developed on (and recomended specs) are:
Intel(R) Core(TM) i7-8700K CPU @ 3.70GHz
NVIDIA GeForce RTX 3080 Ti
32GB RAM
